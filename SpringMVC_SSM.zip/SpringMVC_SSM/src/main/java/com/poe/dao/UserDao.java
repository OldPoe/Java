package com.poe.dao;

import com.poe.entity.User;
import org.apache.ibatis.annotations.Param;

import java.util.ArrayList;
import java.util.List;


public interface UserDao {

    // 根据 id 寻找对应的 User
    User findUserById(int id);
    User findUserByUsername(String name);
    int getCount();
    ArrayList<User> selectSelective(User record);
    ArrayList<User> selectLike(User record);
    //添加用户
    void addUser(User user);

    //根据用户名和密码查询用户
    //注解的两个参数会自动封装成map集合，括号内即为键
    User findUserByNameAndPwd(@Param("username")String username, @Param("password")String password);

    List<User> findAllUser();
    void del(int id);
}