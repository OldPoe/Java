package com.poe.service;

import com.poe.entity.PageBean;
import com.poe.entity.User;

public interface UserService {

    // 根据 id 寻找对应的 User
     User findUserById(int id);
     User findUserByUsername(String name);
     User findUserByNameAndPwd(String username,String password);
     void addUser(User user);
    public PageBean<User> findAllUser(int pageNum, int pageSize);
}