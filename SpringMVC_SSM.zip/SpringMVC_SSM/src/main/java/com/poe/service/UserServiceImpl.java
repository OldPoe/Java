package com.poe.service;


import com.poe.dao.UserDao;
import com.poe.entity.PageBean;
import com.poe.entity.User;

import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.awt.print.Pageable;
import java.util.List;


@Service("userService")
public class UserServiceImpl implements UserService {

    @Resource
    private UserDao userDao;

    public User findUserById(int id) {
        return userDao.findUserById(id);
    }

    public User findUserByUsername(String name){
        return userDao.findUserByUsername(name);
    }

    public User findUserByNameAndPwd(String username, String password) {
        return userDao.findUserByNameAndPwd(username,password);
    }
    public void addUser(User user){
        userDao.addUser(user);
    }
    public PageBean<User> findAllUser(int pageNum, int pageSize){
        List<User> allUser = userDao.findAllUser();
        int totalRecord = allUser.size();
        PageBean pb = new PageBean(pageNum,pageSize,totalRecord);
        int startIndex = pb.getStartIndex();
        pb.setList(allUser.subList(startIndex,startIndex+pageSize>totalRecord?totalRecord:startIndex+pageSize));
        return pb;
    }
}