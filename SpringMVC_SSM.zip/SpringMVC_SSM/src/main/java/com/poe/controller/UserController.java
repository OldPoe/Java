package com.poe.controller;

import com.poe.entity.PageBean;
import com.poe.entity.User;
import com.poe.service.UserService;
import com.sun.org.apache.xpath.internal.operations.Mod;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


@Controller
@RequestMapping("")
public class UserController {

    @Resource
    private UserService userService;

    @RequestMapping("/findUser")
    public String findUser(Model model) {
        int id = 1;
        User user = this.userService.findUserById(id);
        model.addAttribute("user", user);
        return "index";
    }

    @RequestMapping("/findUser2")
    public String findUser1(Model model) {
       String name="我";
        User user = this.userService.findUserByUsername(name);
        model.addAttribute("user", user);
        return "index";
    }
    @RequestMapping("/login")
    public String login(HttpServletRequest request, User user, Model model){
        if(user.getUsername()!=null && !user.getUsername().equals("") && user.getPassword()!=null && !user.getPassword().equals("")){
            System.out.println(user.getUsername()+user.getPassword());
            User currUser = this.userService.findUserByNameAndPwd(user.getUsername(),user.getPassword());
            if(currUser!=null){
                HttpSession session = request.getSession(true);
                session.setAttribute("user", user);
                model.addAttribute("user", user);
                
                return "success";
            }else {

                model.addAttribute("LoginError", "用户名或密码错误。");
                return "redirect:/login.jsp";
            }
        }else {
            model.addAttribute("LoginError", "用户名或密码不能为零。");
            return "redirect:/login.jsp";
        }


    }
    @RequestMapping("/regist")
    public String regist(User user,Model model){
        if(user.getUsername()!=null && !user.getUsername().equals("") && user.getPassword()!=null && !user.getPassword().equals("")){
        this.userService.addUser(user);

        model.addAttribute("user",user);
        return "success";
        } else{
            model.addAttribute("LoginError", "用户名或密码不能为零。");
            return "redirect:/login.jsp";
        }
    }
    @RequestMapping("/manage")
    public String manage(int pageNum,Model model){
        int currPage ;
        if( pageNum!=0){
            currPage=pageNum;
        }else {
            currPage = 1;
        }
        int pageSize = 5;
        PageBean pb = userService.findAllUser(currPage,pageSize);
        model.addAttribute("pageBean",pb);
        return "userManage";
    }
    @RequestMapping("/del")
    public String del(int id,int currPage,Model model){

    }

}