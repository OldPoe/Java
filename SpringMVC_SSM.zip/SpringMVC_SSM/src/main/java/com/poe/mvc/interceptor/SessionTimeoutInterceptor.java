package com.poe.mvc.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Created by Poe on 2018/8/24.
 */
public class SessionTimeoutInterceptor implements HandlerInterceptor {
    private static final String LOGIN_URL = "/login.jsp";

    public void postHandle(HttpServletRequest request,
                           HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {

    }

    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response, Object handler, Exception ex)
            throws Exception {

    }

    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {
        HttpSession session = request.getSession(true);
        //session中获取用户名信息
        Object obj = session.getAttribute("user");
        if (obj == null || "".equals(obj.toString())) {
            System.out.println("拦截");
            response.sendRedirect(request.getSession().getServletContext().getContextPath() + LOGIN_URL);
            return false;
        }
        return true;
    }
}