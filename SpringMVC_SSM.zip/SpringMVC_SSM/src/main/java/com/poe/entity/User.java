package com.poe.entity;



public class User {


    private Integer id;
    private String username;
    private String password;
    private String profile="\\resource\\uploads\\2018\\8\\Angelic_Pretty.jpg";
//="F:\\apache-tomcat-7.0.75\\apache-tomcat-7.0.75\\webapps\\web-ssm\\resource\\uploads\\2018\\8\\sliver20180823165516730.jpg"
    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public User() {
    }

    @Override
    public String toString() {

        return super.toString()+" "+id+" "+username+" "+profile;
    }

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getProfile() {
        return profile;
    }

    public void setProfile(String profilePhoto) {
        this.profile = profilePhoto;
    }
}