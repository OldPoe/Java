import com.poe.dao.UserDao;
import com.poe.entity.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.List;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"classpath:spring-mybatis.xml"})
public class UserDaoTest {


    @Autowired
    private UserDao userDao;

    //查询数量
    @Test
    public void getCount() throws Exception{
        System.out.println(userDao.getCount());
    }
    //登陆测试
    @Test
    public void findUserByNameAndPwd() throws Exception{
        User reslut = userDao.findUserByNameAndPwd("你","13");
        if(reslut!=null){
            System.out.println(reslut);
        }else  System.out.println("error");
    }
    //准确查询
    @Test
    public void selectSelective() throws Exception{
        User user=new User();
        //此处的("123")即查询我数据表中，密码为123的那一列，你可以自己查询id或者名字
        user.setPassword("123");
        ArrayList<User> list = userDao.selectSelective(user);
        for (User a:list){
            System.out.println(a.toString());
        }
    }
    @Test
    public void findAllUser()throws Exception{
        List<User> list = userDao.findAllUser();
        for (User a:list){
            System.out.println(a.toString());
        }
    }
//    模糊查询，查询Name中包含了2的数据
    @Test
    public void selectLike() throws Exception{
        User user=new User();
        user.setUsername("你");
        ArrayList<User> list=userDao.selectLike(user);
        for (User a:list){
            System.out.println(a);
        }
    }
}